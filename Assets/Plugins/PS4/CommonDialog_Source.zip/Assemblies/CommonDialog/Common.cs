﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace PS4
	{
		namespace Dialog
		{
			public class Common
			{
				// System message dialog types, these must exactly match the values defined by SceMsgDialogSystemMessageType.
				public enum SystemMessageType
				{
					TRC_EMPTY_STORE = 0,
					TRC_PSN_CHAT_RESTRICTION = 1,
					TRC_PSN_UGC_RESTRICTION = 2,
					WARNING_SWITCH_TO_SIMULVIEW = 3,
					CAMERA_NOT_CONNECTED = 4,
					WARNING_PROFILE_PICTURE_AND_NAME_NOT_SHARED = 5,
				}

				// User message dialog types, these must exactly match the values defined by SceMsgDialogButtonType.
				public enum UserMessageType
				{
					OK				= 0,
					YESNO			= 1,
					NONE			= 2,
					OK_CANCEL		= 3,
					CANCEL			= 4,
				}

				public enum CommonDialogResult
				{
					RESULT_BUTTON_NOT_SET,
					RESULT_BUTTON_OK,
					RESULT_BUTTON_CANCEL,
					RESULT_BUTTON_YES,
					RESULT_BUTTON_NO,
					RESULT_BUTTON_1,
					RESULT_BUTTON_2,
					RESULT_BUTTON_3,
					RESULT_CANCELED,
					RESULT_ABORTED,
					RESULT_CLOSED,
				}

				[DllImport("CommonDialog")]
				private static extern int PrxCommonDialogInitialise();
				[DllImport("CommonDialog")]
				private static extern void PrxCommonDialogUpdate();

				[DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogIsDialogOpen();

				[DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogErrorMessage(UInt32 errorCode);

				[DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogSystemMessage(SystemMessageType type,  int userId);
				[DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogClose();

                [DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
                private static extern bool PrxErrorDialogIsDialogOpen();
				
				[DllImport("CommonDialog", CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBar(string str);
				[DllImport("CommonDialog")] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBarSetPercent(int percent);
				[DllImport("CommonDialog", CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogProgressBarSetMessage(string str);

				[DllImport("CommonDialog", CharSet = CharSet.Ansi)] [return:MarshalAs(UnmanagedType.I1)]
				private static extern bool PrxCommonDialogUserMessage(UserMessageType type, bool infobar, string str, string button1, string button2, string button3);

				[DllImport("CommonDialog")]
				private static extern CommonDialogResult PrxCommonDialogGetResult();

				// Event handlers.
				public static event Dialog.Messages.EventHandler OnGotDialogResult;

				// Is a common dialog open?
				public static bool IsDialogOpen
				{
					get { return PrxCommonDialogIsDialogOpen(); }
				}

                // Is the error dialog open?
                public static bool IsErrorDialogOpen
                {
                    get { return PrxErrorDialogIsDialogOpen(); }
                }

				// Display an error message.
				public static bool ShowErrorMessage(UInt32 errorCode)
				{
					return PrxCommonDialogErrorMessage(errorCode);
				}

				// Display a system message.
				public static bool ShowSystemMessage(SystemMessageType type,  int userId)
				{
					return PrxCommonDialogSystemMessage(type, userId);
				}

				// Display a progress bar.
				public static bool ShowProgressBar(string message)
				{
					return PrxCommonDialogProgressBar(message);
				}

				// Set progress bar percentage (0-100).
				public static bool SetProgressBarPercent(int percent)
				{
					return PrxCommonDialogProgressBarSetPercent(percent);
				}

				// Set progress bar message string.
				public static bool SetProgressBarMessage(string message)
				{
					return PrxCommonDialogProgressBarSetMessage(message);
				}

				// Show a user message.
				public static bool ShowUserMessage(UserMessageType type, bool infoBar, string str)
				{
					return PrxCommonDialogUserMessage(type, infoBar, str, "1", "2", "3");
				}

				
				// Close the dialog.
				public static bool Close()
				{
					return PrxCommonDialogClose();
				}

				// Get the result from the dialog that's just closed.
				public static CommonDialogResult GetResult()
				{
					CommonDialogResult result = PrxCommonDialogGetResult();
					return result;
				}

				// Process messages.
				public static void ProcessMessage(Dialog.Messages.PluginMessage msg)
				{
					// Interpret the message and trigger corresponding events.
					switch (msg.type)
					{
						case Dialog.Messages.MessageType.kDialog_GotDialogResult:
							if (OnGotDialogResult != null) OnGotDialogResult(msg);
							break;
					}
				}

				public static void Initialise()
				{
					PrxCommonDialogInitialise();
				}

				public static void Update()
				{
					PrxCommonDialogUpdate();
				}
			}
		} // Dialog
	} // PS4
} // Sony
